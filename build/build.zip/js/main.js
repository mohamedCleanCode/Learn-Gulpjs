var one,two;function one(){}document.getElementById("one").innerHTML="hello from 1",document.getElementById("two").innerHTML="hello from 2";
//# sourceMappingURL=main.js.map
